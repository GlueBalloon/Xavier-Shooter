Colors = {}
local red = { r=255, g=0, b=0 }
local green = { r=0, g=255, b=0 }
local yellow = { r=255, g=255, b=0 }
local pink = { r=255, g=0, b=255 }
local blue = { r=0, g=0, b=255 }
local turquoise = { r=0, g=255, b=255 }
local greenyello = { r=127, g=255, b=0 }
local violet = { r=127, g=0, b=255 }
local lightblue = { r=0, g=127, b=255 }
local lightgreen = { r=0, g=255, b=127 }
local orange = { r=255, g=127, b=0 }

table.insert(Colors, turquoise)
table.insert(Colors, orange)
table.insert(Colors, green)
table.insert(Colors, yellow)
table.insert(Colors, pink)
table.insert(Colors, blue)
table.insert(Colors, red)
table.insert(Colors, greenyellow)
table.insert(Colors, violet)
table.insert(Colors, lightblue)
table.insert(Colors, lightgreen)

